/*
 * Copyright 2017 Red Hat, Inc. and/or its affiliates.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.jbpm.springboot.samples;

import java.util.Collection;

import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import org.jbpm.kie.services.impl.KModuleDeploymentUnit;
import org.jbpm.services.api.DeploymentService;
import org.jbpm.services.api.ProcessService;
import org.jbpm.services.api.RuntimeDataService;
import org.jbpm.services.api.model.ProcessDefinition;
import org.kie.api.KieBase;
import org.kie.api.KieServices;
import org.kie.api.runtime.KieContainer;
import org.kie.api.runtime.KieSession;
import org.kie.api.runtime.manager.RuntimeEngine;
import org.kie.api.runtime.manager.RuntimeEnvironmentBuilder;
import org.kie.api.runtime.manager.RuntimeManager;
import org.kie.api.runtime.manager.RuntimeManagerFactory;
import org.kie.api.runtime.query.QueryContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

@SpringBootApplication
public class JBPMApplication {

	private static final Logger LOGGER = LoggerFactory.getLogger(JBPMApplication.class);

	public static void main(String[] args) {
		SpringApplication.run(JBPMApplication.class, args);
	}

	@Bean
	CommandLineRunner deployAndValidate() {
		return new CommandLineRunner() {

			@Autowired
			private DeploymentService deploymentService;

			@Autowired
			private RuntimeDataService runtimeDataService;

			@Autowired
			private ProcessService processService;

			@Override
			public void run(String... strings) throws Exception {
				KieServices ks = KieServices.Factory.get(); 
				
				KieContainer kContainer = ks.getKieClasspathContainer();
				KieBase kbase = kContainer.getKieBase();
				//.getKieBase("kbase");
				EntityManagerFactory emf = Persistence.createEntityManagerFactory(
						"org.jbpm.persistence.jpa");
				RuntimeEnvironmentBuilder builder = RuntimeEnvironmentBuilder.Factory.get()
						.newDefaultBuilder().entityManagerFactory(emf)
						.knowledgeBase(kbase);
					//	Using the runtime environment, create the runtime manager:
						RuntimeManager manager = RuntimeManagerFactory.Factory.get()
						.newSingletonRuntimeManager(builder.get(), "com.packt:introductory-sample:1.0");
						
						RuntimeEngine engine = manager.getRuntimeEngine(null);
						KieSession ksession = engine.getKieSession();
						ksession.startProcess("com.sample.bpmn.hello");
						
				/*
				 * 
				 * KieServices ks = KieServices.Factory.get(); KieContainer kContainer =
				 * ks.getKieClasspathContainer(); KieBase kbase =
				 * kContainer.getKieBase("kbase");
				 * 
				 * RuntimeManager manager = createRuntimeManager(kbase); RuntimeEngine engine =
				 * manager.getRuntimeEngine(null); KieSession ksession = engine.getKieSession();
				 * //Account account = new Account(); //account.setMoney(0);
				 * //ksession.insert(account); Message message = new Message();
				 * message.setMessage("rules message set from main class");
				 * message.setStatus(Message.HELLO); ksession.insert(message); //
				 * ksession.fireAllRules(); ksession.startProcess("com.sample.bpmn.hello");
				 * ksession.getAgenda().getAgendaGroup("dog").setFocus();
				 * ksession.fireAllRules();
				 * 
				 * manager.disposeRuntimeEngine(engine); System.exit(0);
				 * 
				 * 
				 * 
				 * 
				 * String processId = "com.minerva.bpmn.helloworld"; long processInstanceId=0;
				 * KModuleDeploymentUnit unit = null; if (strings.length > 0) { String arg =
				 * strings[0]; LOGGER.info("About to deploy : {}", arg);
				 * 
				 * String[] gav = arg.split(":");
				 * 
				 * unit = new KModuleDeploymentUnit(gav[0], gav[1], gav[2]);
				 * deploymentService.deploy(unit); LOGGER.info("{} successfully deployed", arg);
				 * } LOGGER.info("Available processes:"); Collection<ProcessDefinition>
				 * processes = runtimeDataService.getProcesses(new QueryContext());
				 * System.out.println("shikhaa"); for (ProcessDefinition def : processes) {
				 * System.out.println("shikhacccc\t{} (with id '{})"+ def.getName()+" and ids="+
				 * def.getId()); } System.out.println("shikhaddddd"); if (unit != null &&
				 * !processes.isEmpty()) { System.out.println("shikha"); // String processId =
				 * processes.iterator().next().getId();
				 * 
				 * LOGGER.info("About to start process with id {}", processId);
				 * processInstanceId = processService.startProcess(unit.getIdentifier(),
				 * processId); LOGGER.info("Started instance of {} process with id {}",
				 * processId, processInstanceId);
				 * 
				 * processService.abortProcessInstance(processInstanceId);
				 * //LOGGER.info("Aborted instance with id {}", processInstanceId); }
				 * System.out.println("========= Verification completed successfully ========="
				 * +processInstanceId+" and shikha="+processId); }
				 */}
		};
	}

	private static RuntimeManager createRuntimeManager(KieBase kbase) {
		// JBPMHelper.startH2Server();
		// JBPMHelper.setupDataSource();
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("org.jbpm.persistence.jpa");
		RuntimeEnvironmentBuilder builder = RuntimeEnvironmentBuilder.Factory.get().newDefaultBuilder()
				.entityManagerFactory(emf).knowledgeBase(kbase);
		return RuntimeManagerFactory.Factory.get().newSingletonRuntimeManager(builder.get(), "com.sample:example:1.0");
	}
}
